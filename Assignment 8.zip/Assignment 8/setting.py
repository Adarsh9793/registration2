INSTALLED_APPS = [
    ...
    'accounts',
]

LOGIN_REDIRECT_URL = 'home'
LOGOUT_REDIRECT_URL = 'login'